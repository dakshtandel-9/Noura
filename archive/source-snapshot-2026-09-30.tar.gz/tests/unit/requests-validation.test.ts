import { test } from "node:test";
import assert from "node:assert/strict";
import {
  LIMITS,
  isoDate,
  validateInvitation,
  validateSession,
  type InvitationInput,
  type SessionInput,
} from "../../lib/validation/requests.ts";

// Fictional data only (docs/data-model.md → sample data policy).
const validInvitation: InvitationInput = {
  fullName: "Asha Example",
  email: "asha@example.com",
  phone: "",
  referralSource: "",
  interests: "Quiet mornings and a slower yoga practice.",
  privacyAcknowledged: true,
};

const validSession: SessionInput = {
  fullName: "Asha Example",
  email: "asha@example.com",
  phone: "+91 00000 00000",
  sessionType: "Meditation",
  preferredDate: "",
  message: "",
  privacyAcknowledged: true,
};

test("valid invitation has no errors", () => {
  assert.deepEqual(validateInvitation(validInvitation), {});
});

test("invitation requires name, email, interests and acknowledgement", () => {
  const errors = validateInvitation({
    ...validInvitation,
    fullName: " ",
    email: "",
    interests: "",
    privacyAcknowledged: false,
  });
  assert.deepEqual(Object.keys(errors).sort(), ["email", "fullName", "interests", "privacyAcknowledged"]);
});

test("names are trimmed and bounded but not forced into two words", () => {
  assert.equal(validateInvitation({ ...validInvitation, fullName: "Zo" }).fullName, undefined);
  assert.ok(validateInvitation({ ...validInvitation, fullName: " A " }).fullName);
  assert.ok(validateInvitation({ ...validInvitation, fullName: "x".repeat(LIMITS.nameMax + 1) }).fullName);
});

test("email must look like an address and stay within 254 characters", () => {
  assert.ok(validateInvitation({ ...validInvitation, email: "not-an-email" }).email);
  assert.ok(validateInvitation({ ...validInvitation, email: `${"a".repeat(250)}@example.com` }).email);
});

test("interests enforce 10–1000 characters", () => {
  assert.ok(validateInvitation({ ...validInvitation, interests: "too short" }).interests);
  assert.ok(validateInvitation({ ...validInvitation, interests: "x".repeat(LIMITS.interestsMax + 1) }).interests);
});

test("referral source must be an approved option", () => {
  assert.equal(validateInvitation({ ...validInvitation, referralSource: "Search" }).referralSource, undefined);
  assert.ok(validateInvitation({ ...validInvitation, referralSource: "<script>" }).referralSource);
});

test("valid session request has no errors", () => {
  assert.deepEqual(validateSession(validSession, "2026-09-28"), {});
});

test("session type must be one of the approved experiences", () => {
  assert.ok(validateSession({ ...validSession, sessionType: "" }, "2026-09-28").sessionType);
  assert.ok(validateSession({ ...validSession, sessionType: "Massage" }, "2026-09-28").sessionType);
});

test("preferred date is optional, but a past date is rejected", () => {
  const today = "2026-09-28";
  assert.equal(validateSession({ ...validSession, preferredDate: today }, today).preferredDate, undefined);
  assert.equal(validateSession({ ...validSession, preferredDate: "2026-10-02" }, today).preferredDate, undefined);
  assert.ok(validateSession({ ...validSession, preferredDate: "2026-09-27" }, today).preferredDate);
  assert.ok(validateSession({ ...validSession, preferredDate: "28/09/2026" }, today).preferredDate);
});

test("message is optional and limited to 1000 characters", () => {
  assert.ok(validateSession({ ...validSession, message: "x".repeat(LIMITS.messageMax + 1) }, "2026-09-28").message);
});

test("phone accepts common formatting only", () => {
  assert.equal(validateSession({ ...validSession, phone: "+44 (0)20 0000-0000" }, "2026-09-28").phone, undefined);
  assert.ok(validateSession({ ...validSession, phone: "call me maybe" }, "2026-09-28").phone);
});

test("isoDate formats a local calendar date", () => {
  assert.equal(isoDate(new Date(2026, 0, 5)), "2026-01-05");
});
