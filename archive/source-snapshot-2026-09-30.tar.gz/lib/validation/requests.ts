/**
 * Field rules for the two public request forms (docs/requirements.md → field dictionaries).
 *
 * This module is framework-free so the same rules run in the browser today and in the
 * future server route handlers (`app/api/requests/*`). Client validation is a courtesy;
 * the server must re-run these checks before any write (FR-07, FORM-03/04).
 */

export const SESSION_TYPES = [
  "Yoga",
  "Meditation",
  "Music & Sound",
  "Private Group Sessions",
  "Not sure yet",
] as const;
export type SessionType = (typeof SESSION_TYPES)[number];

export const REFERRAL_SOURCES = ["Personal referral", "Search", "Social media", "Other"] as const;
export type ReferralSource = (typeof REFERRAL_SOURCES)[number];

export const LIMITS = {
  nameMin: 2,
  nameMax: 100,
  emailMax: 254,
  phoneMax: 30,
  interestsMin: 10,
  interestsMax: 1000,
  messageMax: 1000,
} as const;

export interface InvitationInput {
  fullName: string;
  email: string;
  phone: string;
  referralSource: string;
  interests: string;
  privacyAcknowledged: boolean;
}

export interface SessionInput {
  fullName: string;
  email: string;
  phone: string;
  sessionType: string;
  preferredDate: string;
  message: string;
  privacyAcknowledged: boolean;
}

export type FieldErrors<T> = Partial<Record<keyof T, string>>;

// Deliberately permissive: one "@", a dot in the domain, no whitespace.
// Deliverability is confirmed by the team's follow-up, not by a regex.
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_PATTERN = /^[+()\-.\s0-9]*$/;
const ISO_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function checkName(value: string): string | undefined {
  const name = value.trim();
  if (!name) return "Please enter your name.";
  if (name.length < LIMITS.nameMin) return `Please enter at least ${LIMITS.nameMin} characters.`;
  if (name.length > LIMITS.nameMax) return `Please keep your name under ${LIMITS.nameMax} characters.`;
  return undefined;
}

function checkEmail(value: string): string | undefined {
  const email = value.trim();
  if (!email) return "Please enter your email address.";
  if (email.length > LIMITS.emailMax || !EMAIL_PATTERN.test(email)) {
    return "Please enter a valid email address, for example name@example.com.";
  }
  return undefined;
}

function checkPhone(value: string): string | undefined {
  const phone = value.trim();
  if (!phone) return undefined;
  if (phone.length > LIMITS.phoneMax) return `Please keep the phone number under ${LIMITS.phoneMax} characters.`;
  if (!PHONE_PATTERN.test(phone)) return "Please use digits, spaces and + ( ) - only.";
  return undefined;
}

function checkAcknowledgement(value: boolean): string | undefined {
  return value ? undefined : "Please confirm you have read the notice.";
}

export function validateInvitation(input: InvitationInput): FieldErrors<InvitationInput> {
  const errors: FieldErrors<InvitationInput> = {};
  const interests = input.interests.trim();

  errors.fullName = checkName(input.fullName);
  errors.email = checkEmail(input.email);
  errors.phone = checkPhone(input.phone);
  if (input.referralSource && !(REFERRAL_SOURCES as readonly string[]).includes(input.referralSource)) {
    errors.referralSource = "Please choose one of the listed options.";
  }
  if (!interests) errors.interests = "Please share a little about what draws you to NOURA.";
  else if (interests.length < LIMITS.interestsMin) errors.interests = `Please write at least ${LIMITS.interestsMin} characters.`;
  else if (interests.length > LIMITS.interestsMax) errors.interests = `Please keep this under ${LIMITS.interestsMax} characters.`;
  errors.privacyAcknowledged = checkAcknowledgement(input.privacyAcknowledged);

  return compact(errors);
}

/**
 * `today` is an ISO date (YYYY-MM-DD) in the operating timezone. The timezone is a pending
 * client decision (docs/requirements.md); the server must supply it rather than trust the browser.
 */
export function validateSession(input: SessionInput, today: string): FieldErrors<SessionInput> {
  const errors: FieldErrors<SessionInput> = {};

  errors.fullName = checkName(input.fullName);
  errors.email = checkEmail(input.email);
  errors.phone = checkPhone(input.phone);
  if (!input.sessionType) errors.sessionType = "Please choose an experience.";
  else if (!(SESSION_TYPES as readonly string[]).includes(input.sessionType)) {
    errors.sessionType = "Please choose one of the listed experiences.";
  }
  if (input.preferredDate) {
    if (!ISO_DATE_PATTERN.test(input.preferredDate) || Number.isNaN(Date.parse(input.preferredDate))) {
      errors.preferredDate = "Please choose a valid date.";
    } else if (input.preferredDate < today) {
      errors.preferredDate = "Please choose today or a later date.";
    }
  }
  if (input.message.trim().length > LIMITS.messageMax) {
    errors.message = `Please keep your message under ${LIMITS.messageMax} characters.`;
  }
  errors.privacyAcknowledged = checkAcknowledgement(input.privacyAcknowledged);

  return compact(errors);
}

export function isSessionType(value: string): value is SessionType {
  return (SESSION_TYPES as readonly string[]).includes(value);
}

/** Local calendar date as YYYY-MM-DD. */
export function isoDate(date: Date): string {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

function compact<T>(errors: FieldErrors<T>): FieldErrors<T> {
  const result: FieldErrors<T> = {};
  for (const key of Object.keys(errors) as (keyof T)[]) {
    if (errors[key]) result[key] = errors[key];
  }
  return result;
}
