import { site } from "@/content/site";

export type RequestKind = "invitation" | "session";

export type SubmitResult =
  | { status: "preview" }
  | { status: "received" }
  | { status: "invalid"; fieldErrors: Record<string, string> }
  | { status: "rate-limited" }
  | { status: "network-error" }
  | { status: "server-error" };

/**
 * Sends a request to the narrow public endpoint (docs/architecture.md → server contracts):
 * 201 created / 200 idempotent replay → received; 422 → field errors; 429 → rate limited.
 *
 * While `site.requestsMode` is "preview" nothing leaves the browser. The endpoints are
 * implemented in the backend slice; switch the mode only once they store requests.
 */
export async function submitRequest(
  kind: RequestKind,
  payload: Record<string, unknown>,
  idempotencyKey: string,
): Promise<SubmitResult> {
  if (site.requestsMode === "preview") return { status: "preview" };

  let response: Response;
  try {
    response = await fetch(`/api/requests/${kind}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Idempotency-Key": idempotencyKey },
      body: JSON.stringify(payload),
    });
  } catch {
    return { status: "network-error" };
  }

  if (response.status === 200 || response.status === 201) return { status: "received" };
  if (response.status === 429) return { status: "rate-limited" };
  if (response.status === 422) {
    const body = (await response.json().catch(() => null)) as { fieldErrors?: Record<string, string> } | null;
    return { status: "invalid", fieldErrors: body?.fieldErrors ?? {} };
  }
  return { status: "server-error" };
}

export function newIdempotencyKey() {
  return crypto.randomUUID();
}
