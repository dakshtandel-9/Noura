import type { SessionType } from "@/lib/validation/requests";

/** Chapter CTAs → private-session form: preselect a programme without submitting. */
export const SELECT_SESSION_EVENT = "noura:select-session";
/** Any "Privacy / Terms" trigger → the single notice dialog. */
export const OPEN_NOTICE_EVENT = "noura:open-notice";

export function selectSession(sessionType: SessionType) {
  window.dispatchEvent(new CustomEvent<SessionType>(SELECT_SESSION_EVENT, { detail: sessionType }));
}

export function openNotice(trigger: HTMLElement | null) {
  window.dispatchEvent(new CustomEvent<HTMLElement | null>(OPEN_NOTICE_EVENT, { detail: trigger }));
}
