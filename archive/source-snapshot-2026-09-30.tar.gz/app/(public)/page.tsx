import { InvitationSection, SessionSection } from "@/components/forms/RequestSections";
import { NoticeDialog } from "@/components/layout/NoticeDialog";
import { RevealObserver } from "@/components/layout/RevealObserver";
import { SiteFooter } from "@/components/layout/SiteFooter";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { ConnectionChapter, ExperienceChapter } from "@/components/story/ExperienceChapter";
import { ExperienceIndex } from "@/components/story/ExperienceIndex";
import { ExperienceStrip } from "@/components/story/ExperienceStrip";
import { Faq } from "@/components/story/Faq";
import { Hero } from "@/components/story/Hero";
import { PauseInterlude, SensoryPause } from "@/components/story/Interludes";
import { MemberIdentity } from "@/components/story/MemberIdentity";
import { Philosophy } from "@/components/story/Philosophy";
import { CareSection, InvitationJourney, SessionRhythm } from "@/components/story/Process";
import { programme } from "@/content/programmes";

/**
 * The single long landing page. Section order is the approved narrative in
 * docs/site-structure.md (00–17): arrival → overview strip → pause → intention → four ways → chapters →
 * rhythm → sensory pause → access → member identity → care → questions → forms → close.
 */
export default function HomePage() {
  return (
    <>
      <SiteHeader />
      <main id="main" tabIndex={-1}>
        <Hero />
        <ExperienceStrip />
        <PauseInterlude />
        <Philosophy />
        <ExperienceIndex />
        <ExperienceChapter programme={programme("yoga")} layout="split" />
        <ExperienceChapter programme={programme("meditation")} layout="reverse" />
        <ExperienceChapter programme={programme("sound")} layout="dark" />
        <ConnectionChapter programme={programme("connection")} />
        <SessionRhythm />
        <SensoryPause />
        <InvitationJourney />
        <MemberIdentity />
        <CareSection />
        <Faq />
        <InvitationSection />
        <SessionSection />
      </main>
      <SiteFooter />
      <NoticeDialog />
      <RevealObserver />
    </>
  );
}
