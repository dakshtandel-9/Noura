import { Lines } from "./Lines";

interface SectionHeadingProps {
  id: string;
  eyebrow: string;
  lines: readonly string[];
  className?: string;
}

export function SectionHeading({ id, eyebrow, lines, className }: SectionHeadingProps) {
  return (
    <>
      <span className="eyebrow">{eyebrow}</span>
      <h2 id={id} className={className}>
        <Lines lines={lines} />
      </h2>
    </>
  );
}
