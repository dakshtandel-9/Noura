import Image from "next/image";

interface PhotoProps {
  src: string;
  width: number;
  height: number;
  alt: string;
  shape?: "portrait" | "landscape" | "wide";
  arch?: boolean;
  /** Offset gold hairline behind the image. */
  framed?: boolean;
  sizes?: string;
  className?: string;
}

/**
 * Editorial still with a reserved aspect ratio (no layout shift) and lazy loading below the fold.
 * Chapter stills are illustrative concept art until approved photography replaces them.
 */
export function Photo({
  src,
  width,
  height,
  alt,
  shape = "landscape",
  arch = false,
  framed = false,
  sizes = "(max-width: 767px) 100vw, 50vw",
  className,
}: PhotoProps) {
  const classes = ["photo", `photo--${shape}`, arch && "photo--arch", framed && "photo--framed", className]
    .filter(Boolean)
    .join(" ");
  return (
    <div className={classes}>
      <div className="photo__inner">
        <Image src={src} width={width} height={height} alt={alt} sizes={sizes} quality={82} />
      </div>
    </div>
  );
}
