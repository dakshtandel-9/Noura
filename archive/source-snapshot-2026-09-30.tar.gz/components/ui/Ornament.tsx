/**
 * A fine gold hairline with a small lozenge — the "restrained Option 4 gold detail".
 * Purely decorative and hidden from assistive technology.
 */
export function Ornament({ align = "center", tone = "gold" }: { align?: "start" | "center"; tone?: "gold" | "light" }) {
  return (
    <span className={`ornament ornament--${align} ornament--${tone}`} aria-hidden="true">
      <span className="ornament__line" />
      <span className="ornament__gem" />
      <span className="ornament__line" />
    </span>
  );
}
