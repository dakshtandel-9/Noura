import { Icon } from "@/components/ui/Icon";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { faqSection, faqs } from "@/content/faqs";
import styles from "./Faq.module.css";

/** 14 — Native details/summary: keyboard accessible without JavaScript, no auto-advance. */
export function Faq() {
  return (
    <section className={`section ${styles.faq}`} id="questions" aria-labelledby="questions-title">
      <div className={`wrap ${styles.inner}`}>
        <div data-reveal>
          <SectionHeading id="questions-title" eyebrow={faqSection.eyebrow} lines={faqSection.titleLines} />
        </div>
        <div className={styles.list}>
          {faqs.map((item) => (
            <details key={item.q} className={styles.item}>
              <summary className={styles.summary}>
                <span>{item.q}</span>
                <span className={styles.toggle}>
                  <Icon name="chevron-down" size={20} />
                </span>
              </summary>
              <p className={styles.answer}>{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
