import { Icon } from "@/components/ui/Icon";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { experiences } from "@/content/home";
import { programmes } from "@/content/programmes";
import styles from "./ExperienceIndex.module.css";

/** 04 — Four icon-led anchor cards; one destination each, no nested controls. */
export function ExperienceIndex() {
  return (
    <section className="section" id="experiences" aria-labelledby="experiences-title">
      <div className="wrap">
        <div className={styles.intro} data-reveal>
          <div>
            <SectionHeading id="experiences-title" eyebrow={experiences.eyebrow} lines={experiences.titleLines} />
          </div>
          <p>{experiences.intro}</p>
        </div>
        <ul className={styles.grid} role="list">
          {programmes.map((p) => (
            <li key={p.id} className={styles.item} data-reveal>
              <a className={styles.tile} href={`#${p.id}`}>
                <Icon name={p.icon} className={styles.icon} size={32} />
                <span className={styles.text}>
                  <span className={styles.verb}>{p.verb}</span>
                  <span className={styles.name}>{p.indexLabel}</span>
                </span>
                <span className={styles.bottom}>
                  <span>{p.number} / Explore</span>
                  <span className={styles.circle}>
                    <Icon name="arrow-down" size={20} />
                  </span>
                </span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
