import { Icon } from "@/components/ui/Icon";
import { Lines } from "@/components/ui/Lines";
import { ways } from "@/content/home";
import { programmes } from "@/content/programmes";
import styles from "./ExperienceStrip.module.css";

/**
 * 01b — A quiet overview band directly under the arrival: heading, the four experiences as
 * icon-led anchors to their chapters, and a link on to the intention. Anchors only, no new pages.
 */
export function ExperienceStrip() {
  return (
    <section className={styles.strip} id="ways" aria-labelledby="ways-title">
      <div className={`wrap ${styles.inner}`} data-reveal>
        <div className={styles.intro}>
          <span className="eyebrow">{ways.eyebrow}</span>
          <h2 id="ways-title" className={styles.title}>
            <Lines lines={ways.titleLines} />
          </h2>
          <span className={styles.rule} aria-hidden="true" />
          <a className={styles.link} href="#experiences">
            <span>{ways.link}</span>
            <Icon name="arrow-right" size={16} />
          </a>
        </div>

        <ul className={styles.list} role="list">
          {programmes.map((p) => (
            <li key={p.id} className={styles.item}>
              <a className={styles.way} href={`#${p.id}`}>
                <Icon name={p.icon} className={styles.icon} size={40} />
                <span className={styles.verb}>{p.verb}</span>
                <span className={styles.strapline}>
                  {p.strapline[0]}
                  <br />
                  {p.strapline[1]}
                </span>
              </a>
            </li>
          ))}
        </ul>

        <div className={styles.aside}>
          <span className={`eyebrow ${styles.asideEyebrow}`}>{ways.aside.eyebrow}</span>
          <p className={styles.asideText}>
            {ways.aside.lines[0]}
            <br />
            {ways.aside.lines[1]}
          </p>
          <a className={styles.link} href="#philosophy">
            <span>{ways.aside.link}</span>
            <Icon name="arrow-right" size={16} />
          </a>
        </div>
      </div>
    </section>
  );
}
