import { TextLink } from "@/components/ui/Button";
import { Photo } from "@/components/ui/Photo";
import { connectionFooter } from "@/content/home";
import type { Programme } from "@/content/programmes";
import { ProgrammeLink } from "./ProgrammeLink";
import styles from "./ExperienceChapter.module.css";

function ChapterAction({ action }: { action: Programme["action"] }) {
  return "sessionType" in action ? (
    <ProgrammeLink sessionType={action.sessionType} label={action.label} />
  ) : (
    <TextLink href={action.href}>{action.label}</TextLink>
  );
}

function ChapterHeading({ programme }: { programme: Programme }) {
  return (
    <>
      <div className={styles.number} aria-hidden="true">
        {programme.number}
      </div>
      <span className="eyebrow">{programme.eyebrow}</span>
      <h2 id={`${programme.id}-title`}>
        {programme.title[0]}
        <br className="br-wide" /> {programme.title[1]}
      </h2>
    </>
  );
}

interface ExperienceChapterProps {
  programme: Programme;
  layout: "split" | "reverse" | "dark";
}

/** 05–07 — Editorial split chapters (Yoga, Meditation, Music & Sound). */
export function ExperienceChapter({ programme, layout }: ExperienceChapterProps) {
  const portrait = layout === "reverse";
  const className = [
    "section",
    styles.chapter,
    layout === "reverse" && styles.reverse,
    layout === "dark" && `${styles.dark} theme-dark`,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <section className={className} id={programme.id} aria-labelledby={`${programme.id}-title`}>
      <div className="wrap editorial">
        <div className={`copy ${styles.copy}`} data-reveal>
          <ChapterHeading programme={programme} />
          <p className="lead">{programme.body}</p>
          <ChapterAction action={programme.action} />
        </div>
        <figure className={styles.figure} data-reveal>
          <Photo
            {...programme.image}
            shape={portrait ? "portrait" : "landscape"}
            arch={portrait}
            framed
          />
          {programme.note && <figcaption className="image-note">{programme.note}</figcaption>}
        </figure>
      </div>
    </section>
  );
}

/** 08 — Private groups: wide still, invitation-led, no capacity or availability claims. */
export function ConnectionChapter({ programme }: { programme: Programme }) {
  return (
    <section className={`section ${styles.connection}`} id={programme.id} aria-labelledby={`${programme.id}-title`}>
      <div className="wrap">
        <div className={styles.connectionTop} data-reveal>
          <div>
            <ChapterHeading programme={programme} />
          </div>
          <p className="lead">{programme.body}</p>
        </div>
        <div data-reveal>
          <Photo {...programme.image} shape="wide" framed sizes="(max-width: 1280px) 100vw, 1240px" />
        </div>
        <div className={styles.connectionBottom}>
          <span className={styles.connectionLabel}>{connectionFooter}</span>
          <ChapterAction action={programme.action} />
        </div>
      </div>
    </section>
  );
}
