import { Icon, type IconName } from "@/components/ui/Icon";
import { Ornament } from "@/components/ui/Ornament";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { care, journey, rhythm } from "@/content/home";
import styles from "./Process.module.css";

/** 09 — Illustrative session rhythm, clearly labelled as pending operational approval. */
export function SessionRhythm() {
  return (
    <section className={`section ${styles.rhythm}`} id="rhythm" aria-labelledby="rhythm-title">
      <div className="wrap">
        <div className={styles.centered} data-reveal>
          <SectionHeading id="rhythm-title" eyebrow={rhythm.eyebrow} lines={rhythm.titleLines} />
          <Ornament />
        </div>
        <ol className={styles.rhythmGrid}>
          {rhythm.steps.map((step, i) => (
            <li key={step.title} className={styles.step} data-reveal>
              <span className={styles.stepIndex}>{String(i + 1).padStart(2, "0")}</span>
              <h3>{step.title}</h3>
              <p>{step.body}</p>
            </li>
          ))}
        </ol>
        <p className={styles.sampleLine}>{rhythm.note}</p>
      </div>
    </section>
  );
}

/** 11 — How access works: a thoughtful welcome, not an instant booking. */
export function InvitationJourney() {
  return (
    <section className={`section ${styles.journey}`} id="journey" aria-labelledby="journey-title">
      <div className="wrap">
        <div data-reveal>
          <SectionHeading id="journey-title" eyebrow={journey.eyebrow} lines={journey.titleLines} />
        </div>
        <ol className={styles.journeyGrid}>
          {journey.steps.map((step, i) => (
            <li key={step.title} className={styles.step} data-reveal>
              <span className={styles.stepTop}>
                <span>{String(i + 1).padStart(2, "0")}</span>
                <Icon name="arrow-right" size={20} />
              </span>
              <h3>{step.title}</h3>
              <p>{step.body}</p>
            </li>
          ))}
        </ol>
        <p className="notice">{journey.notice}</p>
      </div>
    </section>
  );
}

/** 13 — Privacy reassurance. No security absolutes. */
export function CareSection() {
  return (
    <section className="section" id="care" aria-labelledby="care-title">
      <div className="wrap">
        <div data-reveal>
          <SectionHeading id="care-title" eyebrow={care.eyebrow} lines={care.titleLines} />
        </div>
        <ul className={styles.careGrid} role="list">
          {care.items.map((item) => (
            <li key={item.title} className={styles.careItem} data-reveal>
              <span className={styles.careIcon}>
                <Icon name={item.icon as IconName} size={26} />
              </span>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
