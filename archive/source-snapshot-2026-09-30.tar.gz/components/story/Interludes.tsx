import Image from "next/image";
import { Icon } from "@/components/ui/Icon";
import { Ornament } from "@/components/ui/Ornament";
import { pause, space } from "@/content/home";
import { media } from "@/content/site";
import styles from "./Interludes.module.css";

/** 02 — A brief typographic pause. No timer, no enforced breathing exercise. */
export function PauseInterlude() {
  return (
    <section className={styles.pause} id="pause" aria-labelledby="pause-title">
      <div data-reveal>
        <Icon name="lotus" className={styles.pauseIcon} size={36} />
        <h2 id="pause-title" className={styles.pauseTitle}>
          {pause.title}
        </h2>
        <Ornament />
        <p className={styles.pauseBody}>{pause.body}</p>
      </div>
    </section>
  );
}

/** 10 — One wide still with minimal copy. Conceptual setting, not the actual venue. */
export function SensoryPause() {
  return (
    <section className={styles.space} id="space" aria-labelledby="space-title">
      <Image
        className={styles.spaceImage}
        src={media.hero.poster.src}
        alt=""
        fill
        sizes="100vw"
        quality={70}
      />
      <div className={styles.spaceCopy} data-reveal>
        <Ornament tone="light" />
        <h2 id="space-title" className={styles.spaceTitle}>
          {space.title}
        </h2>
        <p className={styles.spaceBody}>
          {space.lines[0]}
          <br />
          {space.lines[1]}
        </p>
      </div>
    </section>
  );
}
