import { Ornament } from "@/components/ui/Ornament";
import { Photo } from "@/components/ui/Photo";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { philosophy } from "@/content/home";
import { media } from "@/content/site";
import styles from "./Philosophy.module.css";

/** 03 — The NOURA intention. Approved philosophy only; no invented founder history. */
export function Philosophy() {
  return (
    <section className={`section ${styles.philosophy}`} id="philosophy" aria-labelledby="philosophy-title">
      <div className="wrap editorial">
        <div className="copy" data-reveal>
          <SectionHeading id="philosophy-title" eyebrow={philosophy.eyebrow} lines={philosophy.titleLines} />
          <Ornament align="start" />
          <p className="lead">{philosophy.lead}</p>
          <p className="quiet">{philosophy.quiet}</p>
        </div>
        <figure className={styles.figure} data-reveal>
          <Photo
            {...media.botanical}
            alt={philosophy.imageAlt}
            shape="portrait"
            arch
            framed
            sizes="(max-width: 767px) 320px, 440px"
          />
          <figcaption className="image-note">{philosophy.imageNote}</figcaption>
        </figure>
      </div>
    </section>
  );
}
