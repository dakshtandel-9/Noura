"use client";

import { TextLink } from "@/components/ui/Button";
import { selectSession } from "@/lib/events";
import type { SessionType } from "@/lib/validation/requests";

/**
 * "Request a [programme] session": scrolls to #private-session, selects the programme and
 * focuses the selector without submitting (docs/components.md → interaction mapping).
 * Without JavaScript it is still a working anchor link.
 */
export function ProgrammeLink({ sessionType, label }: { sessionType: SessionType; label: string }) {
  return (
    <TextLink
      href="#private-session"
      onClick={(e) => {
        e.preventDefault();
        selectSession(sessionType);
      }}
    >
      {label}
    </TextLink>
  );
}
