import Image from "next/image";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { member } from "@/content/home";
import { media } from "@/content/site";
import styles from "./MemberIdentity.module.css";

/**
 * 12 — One illustrative card. Demonstration name and ID only: no live data, no QR,
 * no credential-like token (docs/components.md → MemberCardPreview).
 */
export function MemberIdentity() {
  return (
    <section className={`section ${styles.member}`} id="member" aria-labelledby="member-title">
      <div className="wrap editorial">
        <div className={styles.cardWrap} data-reveal>
          <figure className={styles.card} aria-label="Example member card, demonstration only">
            <span className={styles.cardBorder} aria-hidden="true" />
            <Image
              className={styles.cardLogo}
              src={media.logo.src}
              width={media.logo.width}
              height={media.logo.height}
              alt="NOURA emblem"
              sizes="110px"
            />
            <span className={`eyebrow ${styles.cardLabel}`}>{member.card.label}</span>
            <p className={styles.cardName}>{member.card.name}</p>
            <p className={styles.cardCode}>{member.card.code}</p>
            <figcaption className={styles.cardNote}>{member.card.note}</figcaption>
          </figure>
        </div>
        <div className="copy" data-reveal>
          <SectionHeading id="member-title" eyebrow={member.eyebrow} lines={member.titleLines} />
          <p className="lead">{member.lead}</p>
          <p className="quiet">{member.quiet}</p>
        </div>
      </div>
    </section>
  );
}
