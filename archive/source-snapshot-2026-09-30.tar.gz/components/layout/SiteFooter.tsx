import Image from "next/image";
import { Lines } from "@/components/ui/Lines";
import { Ornament } from "@/components/ui/Ornament";
import { footer } from "@/content/home";
import { media, site } from "@/content/site";
import { NoticeButton } from "./NoticeDialog";
import styles from "./SiteFooter.module.css";

const links = [
  { label: "Philosophy", href: "#philosophy" },
  { label: "Experiences", href: "#experiences" },
  { label: "Invitation", href: "#invitation" },
  { label: "Private session", href: "#private-session" },
];

/** 17 — Closing. Contact and social links render only once the client supplies them. */
export function SiteFooter() {
  const contact = site.publicContact;

  return (
    <footer className={styles.footer} id="footer">
      <div className={styles.main}>
        <div>
          <h2 className={styles.closing}>
            <Lines lines={footer.closing} />
          </h2>
          <Ornament align="start" />
        </div>
        <a href="#arrive" className={styles.logo} aria-label="Back to the top — NOURA home">
          <Image
            src={media.logo.src}
            width={media.logo.width}
            height={media.logo.height}
            alt="NOURA — Illuminate your wellbeing"
            sizes="180px"
          />
        </a>
      </div>

      <div className={styles.bottom}>
        <span className={styles.tagline}>{site.tagline}</span>
        <nav className={styles.links} aria-label="Footer">
          {links.map((l) => (
            <a key={l.href} href={l.href}>
              {l.label}
            </a>
          ))}
          {contact?.email && <a href={`mailto:${contact.email}`}>{contact.email}</a>}
          {site.social.map((s) => (
            <a key={s.href} href={s.href} rel="noopener noreferrer">
              {s.label}
            </a>
          ))}
          <NoticeButton className={styles.policy}>Privacy / Terms</NoticeButton>
        </nav>
      </div>
      <p className={styles.note}>
        © {new Date().getFullYear()} {site.name} · {footer.note}
      </p>
    </footer>
  );
}
