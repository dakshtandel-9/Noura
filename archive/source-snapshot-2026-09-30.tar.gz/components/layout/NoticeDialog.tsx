"use client";

import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/Button";
import { notice } from "@/content/home";
import { OPEN_NOTICE_EVENT, openNotice } from "@/lib/events";

/**
 * Single modal for privacy/terms. Native <dialog> gives focus containment and Escape;
 * focus returns to whichever control opened it. Replace the copy with the client-approved
 * notice before collecting real requests (FR-18).
 */
export function NoticeDialog() {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const trigger = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const onOpen = (e: Event) => {
      trigger.current = (e as CustomEvent<HTMLElement | null>).detail;
      if (!dialog.open) dialog.showModal();
    };
    const onClose = () => trigger.current?.focus();
    window.addEventListener(OPEN_NOTICE_EVENT, onOpen);
    dialog.addEventListener("close", onClose);
    return () => {
      window.removeEventListener(OPEN_NOTICE_EVENT, onOpen);
      dialog.removeEventListener("close", onClose);
    };
  }, []);

  return (
    <dialog
      ref={dialogRef}
      className="notice-dialog"
      aria-labelledby="notice-title"
      onClick={(e) => {
        // Backdrop click closes; clicks inside the panel do not.
        if (e.target === e.currentTarget) e.currentTarget.close();
      }}
    >
      <div className="notice-dialog__panel">
        <span className="eyebrow">NOURA</span>
        <h2 id="notice-title">{notice.title}</h2>
        {notice.paragraphs.map((p) => (
          <p key={p}>{p}</p>
        ))}
        <Button type="button" icon="check" onClick={() => dialogRef.current?.close()}>
          Close notice
        </Button>
      </div>
    </dialog>
  );
}

export function NoticeButton({ children, className }: { children: string; className?: string }) {
  return (
    <button type="button" className={className ?? "policy-link"} onClick={(e) => openNotice(e.currentTarget)}>
      {children}
    </button>
  );
}
