import { Ornament } from "@/components/ui/Ornament";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { invitationSection, sessionSection } from "@/content/home";
import { InvitationForm } from "./InvitationForm";
import { SessionForm } from "./SessionForm";
import styles from "./forms.module.css";

interface IntroProps {
  id: string;
  copy: { eyebrow: string; titleLines: readonly string[]; intro: string; quiet: string };
}

function Intro({ id, copy }: IntroProps) {
  return (
    <div className="copy">
      <SectionHeading id={id} eyebrow={copy.eyebrow} lines={copy.titleLines} />
      <p className={styles.intro}>{copy.intro}</p>
      <Ornament align="start" />
      <p className="quiet">{copy.quiet}</p>
    </div>
  );
}

/** 15 — Invitation request. Manual review; submitting never approves membership. */
export function InvitationSection() {
  return (
    <section className={`section ${styles.section}`} id="invitation" aria-labelledby="invitation-title">
      <div className="wrap editorial">
        <Intro id="invitation-title" copy={invitationSection} />
        <InvitationForm />
      </div>
    </section>
  );
}

/** 16 — Private-session request. A date preference, never an instant confirmation. */
export function SessionSection() {
  return (
    <section
      className={`section ${styles.section} ${styles.privateSection}`}
      id="private-session"
      aria-labelledby="private-session-title"
    >
      <div className="wrap editorial">
        <Intro id="private-session-title" copy={sessionSection} />
        <SessionForm />
      </div>
    </section>
  );
}
