"use client";

import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { requestCopy } from "@/content/home";
import { site } from "@/content/site";
import { openNotice } from "@/lib/events";
import styles from "./forms.module.css";

const isPreview = site.requestsMode === "preview";

export function NoticeLabel() {
  return (
    <>
      I have read the{" "}
      <button type="button" className="policy-link" onClick={(e) => openNotice(e.currentTarget)}>
        {isPreview ? "review notice" : "privacy notice"}
      </button>
      .{isPreview && " I will use fictional details while the site is in review."}
    </>
  );
}

export function PreviewNote() {
  if (!isPreview) return null;
  return <p className={styles.previewNote}>{requestCopy.previewNote}</p>;
}

/** Generic acknowledgement — never reveals membership status or promises a booking. */
export function FormOutcome({ status, onReset }: { status: "preview" | "received"; onReset: () => void }) {
  const headingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    headingRef.current?.focus();
  }, []);

  return (
    <div className={`${styles.box} ${styles.outcome}`} role="status">
      <span className={styles.outcomeIcon}>
        <Icon name="check" size={26} />
      </span>
      <h3 ref={headingRef} tabIndex={-1} className={styles.outcomeTitle}>
        {status === "preview" ? "Thank you — preview only." : "Thank you."}
      </h3>
      <p className={styles.outcomeBody}>{status === "preview" ? requestCopy.preview : requestCopy.received}</p>
      <Button type="button" variant="secondary" icon={null} onClick={onReset}>
        Start a new request
      </Button>
    </div>
  );
}
