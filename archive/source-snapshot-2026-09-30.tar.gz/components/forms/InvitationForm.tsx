"use client";

import { useRef, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/Button";
import { REFERRAL_SOURCES, LIMITS, validateInvitation, type InvitationInput } from "@/lib/validation/requests";
import { Acknowledgement, ErrorSummary, SelectField, TextField, TextareaField } from "./fields";
import { FormOutcome, NoticeLabel, PreviewNote } from "./FormParts";
import { useRequestForm } from "./useRequestForm";
import styles from "./forms.module.css";

const empty: InvitationInput = {
  fullName: "",
  email: "",
  phone: "",
  referralSource: "",
  interests: "",
  privacyAcknowledged: false,
};

const fieldIds: Record<keyof InvitationInput, string> = {
  fullName: "inv-name",
  email: "inv-email",
  phone: "inv-phone",
  referralSource: "inv-source",
  interests: "inv-interests",
  privacyAcknowledged: "inv-ack",
};

export function InvitationForm() {
  const [values, setValues] = useState<InvitationInput>(empty);
  const [attempted, setAttempted] = useState(false);
  const summaryRef = useRef<HTMLDivElement>(null);
  const { status, failure, serverErrors, submit, reset } = useRequestForm("invitation");

  const clientErrors = attempted ? validateInvitation(values) : {};
  const errors = { ...serverErrors, ...clientErrors } as Partial<Record<keyof InvitationInput, string>>;
  const summary = (Object.keys(fieldIds) as (keyof InvitationInput)[])
    .filter((key) => errors[key])
    .map((key) => ({ id: fieldIds[key], message: errors[key]! }));

  const set = <K extends keyof InvitationInput>(key: K, value: InvitationInput[K]) =>
    setValues((v) => ({ ...v, [key]: value }));

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setAttempted(true);
    if (Object.keys(validateInvitation(values)).length > 0) {
      requestAnimationFrame(() => summaryRef.current?.focus());
      return;
    }
    await submit({
      full_name: values.fullName.trim(),
      email: values.email.trim(),
      phone: values.phone.trim() || null,
      referral_source: values.referralSource || null,
      interests: values.interests.trim(),
      privacy_acknowledged: values.privacyAcknowledged,
    });
  }

  if (status === "preview" || status === "received") {
    return (
      <FormOutcome
        status={status}
        onReset={() => {
          setValues(empty);
          setAttempted(false);
          reset();
        }}
      />
    );
  }

  return (
    <form className={styles.box} onSubmit={onSubmit} noValidate aria-label="Invitation request">
      <ErrorSummary ref={summaryRef} errors={summary} />
      <div className={styles.grid}>
        <TextField
          id={fieldIds.fullName}
          label="Full name"
          required
          autoComplete="name"
          maxLength={LIMITS.nameMax}
          value={values.fullName}
          onChange={(e) => set("fullName", e.target.value)}
          error={errors.fullName}
        />
        <TextField
          id={fieldIds.email}
          label="Email address"
          type="email"
          required
          autoComplete="email"
          inputMode="email"
          maxLength={LIMITS.emailMax}
          value={values.email}
          onChange={(e) => set("email", e.target.value)}
          error={errors.email}
        />
        <TextField
          id={fieldIds.phone}
          label="Phone"
          type="tel"
          autoComplete="tel"
          maxLength={LIMITS.phoneMax}
          value={values.phone}
          onChange={(e) => set("phone", e.target.value)}
          error={errors.phone}
        />
        <SelectField
          id={fieldIds.referralSource}
          label="How you found us"
          options={REFERRAL_SOURCES}
          placeholder="Select an option"
          value={values.referralSource}
          onChange={(e) => set("referralSource", e.target.value)}
          error={errors.referralSource}
        />
        <TextareaField
          id={fieldIds.interests}
          label="What draws you to NOURA?"
          required
          helper="A few words about your interest in the experience. Please do not include medical information."
          minLength={LIMITS.interestsMin}
          maxLength={LIMITS.interestsMax}
          rows={5}
          value={values.interests}
          onChange={(e) => set("interests", e.target.value)}
          error={errors.interests}
        />
      </div>

      <Acknowledgement
        id={fieldIds.privacyAcknowledged}
        checked={values.privacyAcknowledged}
        onChange={(checked) => set("privacyAcknowledged", checked)}
        error={errors.privacyAcknowledged}
      >
        <NoticeLabel />
      </Acknowledgement>

      {failure && (
        <p className={styles.failure} role="alert">
          {failure}
        </p>
      )}

      <Button type="submit" className={styles.submit} disabled={status === "submitting"} aria-busy={status === "submitting"}>
        {status === "submitting" ? "Sending your request…" : status === "error" ? "Try again" : "Request an invitation"}
      </Button>
      <PreviewNote />
    </form>
  );
}
