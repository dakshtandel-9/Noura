"use client";

import { useEffect, useRef, useState, useSyncExternalStore, type FormEvent } from "react";
import { Button } from "@/components/ui/Button";
import { SELECT_SESSION_EVENT } from "@/lib/events";
import {
  LIMITS,
  SESSION_TYPES,
  isSessionType,
  isoDate,
  validateSession,
  type SessionInput,
  type SessionType,
} from "@/lib/validation/requests";
import { Acknowledgement, ErrorSummary, SelectField, TextField, TextareaField } from "./fields";
import { FormOutcome, NoticeLabel, PreviewNote } from "./FormParts";
import { useRequestForm } from "./useRequestForm";
import styles from "./forms.module.css";

const empty: SessionInput = {
  fullName: "",
  email: "",
  phone: "",
  sessionType: "",
  preferredDate: "",
  message: "",
  privacyAcknowledged: false,
};

const noSubscribe = () => () => {};
const getToday = () => isoDate(new Date());
const getServerToday = () => "";

const fieldIds: Record<keyof SessionInput, string> = {
  fullName: "ses-name",
  email: "ses-email",
  sessionType: "session-type",
  preferredDate: "ses-date",
  phone: "ses-phone",
  message: "ses-message",
  privacyAcknowledged: "ses-ack",
};

export function SessionForm() {
  const [values, setValues] = useState<SessionInput>(empty);
  const [attempted, setAttempted] = useState(false);
  // Browser-local date guard only; production validates against the approved operating timezone.
  // Empty during server render so the `min` attribute never causes a hydration mismatch.
  const today = useSyncExternalStore(noSubscribe, getToday, getServerToday);
  const summaryRef = useRef<HTMLDivElement>(null);
  const selectRef = useRef<HTMLSelectElement>(null);
  const { status, failure, serverErrors, submit, reset } = useRequestForm("session");

  const set = <K extends keyof SessionInput>(key: K, value: SessionInput[K]) =>
    setValues((v) => ({ ...v, [key]: value }));

  // Chapter CTAs preselect a programme, scroll here and focus the selector — never submit.
  useEffect(() => {
    const onSelect = (e: Event) => {
      const sessionType = (e as CustomEvent<SessionType>).detail;
      if (!isSessionType(sessionType)) return;
      reset();
      setValues((v) => ({ ...v, sessionType }));
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      document.getElementById("private-session")?.scrollIntoView({ behavior: reduced ? "auto" : "smooth" });
      requestAnimationFrame(() => selectRef.current?.focus({ preventScroll: true }));
      history.replaceState(null, "", "#private-session");
    };
    window.addEventListener(SELECT_SESSION_EVENT, onSelect);
    return () => window.removeEventListener(SELECT_SESSION_EVENT, onSelect);
    // `reset` only clears local state; re-binding per render is unnecessary.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const clientErrors = attempted && today ? validateSession(values, today) : {};
  const errors = { ...serverErrors, ...clientErrors } as Partial<Record<keyof SessionInput, string>>;
  const summary = (Object.keys(fieldIds) as (keyof SessionInput)[])
    .filter((key) => errors[key])
    .map((key) => ({ id: fieldIds[key], message: errors[key]! }));

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setAttempted(true);
    const now = today || isoDate(new Date());
    if (Object.keys(validateSession(values, now)).length > 0) {
      requestAnimationFrame(() => summaryRef.current?.focus());
      return;
    }
    await submit({
      full_name: values.fullName.trim(),
      email: values.email.trim(),
      phone: values.phone.trim() || null,
      session_type: values.sessionType,
      preferred_date: values.preferredDate || null,
      message: values.message.trim() || null,
      privacy_acknowledged: values.privacyAcknowledged,
    });
  }

  if (status === "preview" || status === "received") {
    return (
      <FormOutcome
        status={status}
        onReset={() => {
          setValues(empty);
          setAttempted(false);
          reset();
        }}
      />
    );
  }

  return (
    <form className={styles.box} onSubmit={onSubmit} noValidate aria-label="Private session request">
      <ErrorSummary ref={summaryRef} errors={summary} />
      <div className={styles.grid}>
        <TextField
          id={fieldIds.fullName}
          label="Full name"
          required
          autoComplete="name"
          maxLength={LIMITS.nameMax}
          value={values.fullName}
          onChange={(e) => set("fullName", e.target.value)}
          error={errors.fullName}
        />
        <TextField
          id={fieldIds.email}
          label="Email address"
          type="email"
          required
          autoComplete="email"
          inputMode="email"
          maxLength={LIMITS.emailMax}
          value={values.email}
          onChange={(e) => set("email", e.target.value)}
          error={errors.email}
        />
        <SelectField
          ref={selectRef}
          id={fieldIds.sessionType}
          label="Experience"
          required
          options={SESSION_TYPES}
          placeholder="Choose an experience"
          value={values.sessionType}
          onChange={(e) => set("sessionType", e.target.value)}
          error={errors.sessionType}
        />
        <TextField
          id={fieldIds.preferredDate}
          label="Preferred date"
          type="date"
          min={today || undefined}
          helper="A preference, not a reservation."
          value={values.preferredDate}
          onChange={(e) => set("preferredDate", e.target.value)}
          error={errors.preferredDate}
        />
        <TextField
          id={fieldIds.phone}
          label="Phone"
          type="tel"
          autoComplete="tel"
          maxLength={LIMITS.phoneMax}
          full
          value={values.phone}
          onChange={(e) => set("phone", e.target.value)}
          error={errors.phone}
        />
        <TextareaField
          id={fieldIds.message}
          label="Anything to share?"
          helper="Practical preferences only. Please do not include medical information."
          maxLength={LIMITS.messageMax}
          rows={4}
          value={values.message}
          onChange={(e) => set("message", e.target.value)}
          error={errors.message}
        />
      </div>

      <Acknowledgement
        id={fieldIds.privacyAcknowledged}
        checked={values.privacyAcknowledged}
        onChange={(checked) => set("privacyAcknowledged", checked)}
        error={errors.privacyAcknowledged}
      >
        <NoticeLabel />
      </Acknowledgement>

      {failure && (
        <p className={styles.failure} role="alert">
          {failure}
        </p>
      )}

      <Button type="submit" className={styles.submit} disabled={status === "submitting"} aria-busy={status === "submitting"}>
        {status === "submitting" ? "Sending your request…" : status === "error" ? "Try again" : "Request a private session"}
      </Button>
      <PreviewNote />
    </form>
  );
}
