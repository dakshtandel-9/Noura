"use client";

import { forwardRef, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { Icon } from "@/components/ui/Icon";
import styles from "./forms.module.css";

interface FieldShellProps {
  id: string;
  label: string;
  required?: boolean;
  helper?: string;
  error?: string;
  full?: boolean;
  children: ReactNode;
}

export function describedBy(id: string, helper?: string, error?: string) {
  return [helper && `${id}-helper`, error && `${id}-error`].filter(Boolean).join(" ") || undefined;
}

function FieldShell({ id, label, required, helper, error, full, children }: FieldShellProps) {
  return (
    <div className={`${styles.field} ${full ? styles.full : ""} ${error ? styles.invalid : ""}`}>
      <label htmlFor={id} className={styles.label}>
        {label}
        {required ? (
          <span className={styles.required}>
            {" "}
            <span aria-hidden="true">*</span>
            <span className="visually-hidden">(required)</span>
          </span>
        ) : (
          <span className={styles.optional}> · optional</span>
        )}
      </label>
      {children}
      {helper && (
        <p id={`${id}-helper`} className={styles.helper}>
          {helper}
        </p>
      )}
      {error && (
        <p id={`${id}-error`} className={styles.error}>
          <Icon name="info" size={16} />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}

type Common = Omit<FieldShellProps, "children">;

export function TextField({ id, label, required, helper, error, full, ...input }: Common & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <FieldShell {...{ id, label, required, helper, error, full }}>
      <input
        id={id}
        className={styles.control}
        required={required}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(id, helper, error)}
        {...input}
      />
    </FieldShell>
  );
}

export const SelectField = forwardRef<
  HTMLSelectElement,
  Common & SelectHTMLAttributes<HTMLSelectElement> & { options: readonly string[]; placeholder: string }
>(function SelectField({ id, label, required, helper, error, full, options, placeholder, ...select }, ref) {
  return (
    <FieldShell {...{ id, label, required, helper, error, full }}>
      <span className={styles.selectWrap}>
        <select
          ref={ref}
          id={id}
          className={styles.control}
          required={required}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy(id, helper, error)}
          {...select}
        >
          <option value="">{placeholder}</option>
          {options.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
        <Icon name="chevron-down" size={18} className={styles.selectIcon} />
      </span>
    </FieldShell>
  );
});

export function TextareaField({ id, label, required, helper, error, full = true, ...textarea }: Common & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <FieldShell {...{ id, label, required, helper, error, full }}>
      <textarea
        id={id}
        className={`${styles.control} ${styles.textarea}`}
        required={required}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(id, helper, error)}
        {...textarea}
      />
    </FieldShell>
  );
}

export function Acknowledgement({
  id,
  checked,
  onChange,
  error,
  children,
}: {
  id: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div className={styles.ack}>
      <div className={styles.checkline}>
        <input
          id={id}
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
          required
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? `${id}-error` : undefined}
        />
        <label htmlFor={id}>{children}</label>
      </div>
      {error && (
        <p id={`${id}-error`} className={styles.error}>
          <Icon name="info" size={16} />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}

export const ErrorSummary = forwardRef<HTMLDivElement, { errors: { id: string; message: string }[] }>(
  function ErrorSummary({ errors }, ref) {
    if (errors.length === 0) return null;
    return (
      <div ref={ref} className={styles.summary} tabIndex={-1} role="alert">
        <p className={styles.summaryTitle}>
          <Icon name="info" size={18} />
          <span>
            Please review {errors.length === 1 ? "one detail" : `${errors.length} details`} before sending.
          </span>
        </p>
        <ul>
          {errors.map((e) => (
            <li key={e.id}>
              <a href={`#${e.id}`}>{e.message}</a>
            </li>
          ))}
        </ul>
      </div>
    );
  },
);
