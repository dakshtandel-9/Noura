"use client";

import { useRef, useState } from "react";
import { newIdempotencyKey, submitRequest, type RequestKind } from "@/lib/requests/client";

export type FormStatus = "idle" | "submitting" | "preview" | "received" | "error";

const failureCopy = {
  "network-error": "We could not reach the server. Your details are still here — please try again.",
  "server-error": "Something went wrong on our side. Your details are still here — please try again shortly.",
  "rate-limited": "Too many attempts in a short time. Please wait a moment, then try again.",
} as const;

/**
 * Shared submission state for both request forms (docs/components.md → form design states):
 * prevents duplicate submits while processing, keeps the same idempotency key for a deliberate
 * retry after a recoverable failure, and preserves the visitor's input on error.
 */
export function useRequestForm(kind: RequestKind) {
  const [status, setStatus] = useState<FormStatus>("idle");
  const [failure, setFailure] = useState("");
  const [serverErrors, setServerErrors] = useState<Record<string, string>>({});
  const idempotencyKey = useRef<string | null>(null);

  async function submit(payload: Record<string, unknown>) {
    if (status === "submitting") return;
    idempotencyKey.current ??= newIdempotencyKey();
    setStatus("submitting");
    setFailure("");
    setServerErrors({});

    const result = await submitRequest(kind, payload, idempotencyKey.current);
    switch (result.status) {
      case "preview":
      case "received":
        idempotencyKey.current = null;
        setStatus(result.status);
        break;
      case "invalid":
        idempotencyKey.current = null;
        setServerErrors(result.fieldErrors);
        setStatus("idle");
        break;
      default:
        setFailure(failureCopy[result.status]);
        setStatus("error");
    }
  }

  function reset() {
    idempotencyKey.current = null;
    setStatus("idle");
    setFailure("");
  }

  return { status, failure, serverErrors, submit, reset };
}
