import type { IconName } from "@/components/ui/Icon";
import type { SessionType } from "@/lib/validation/requests";
import { media } from "./site";

export interface Programme {
  id: "yoga" | "meditation" | "sound" | "connection";
  number: string;
  verb: string;
  name: string;
  indexLabel: string;
  /** Two short lines for the overview strip under the hero. */
  strapline: [string, string];
  icon: IconName;
  eyebrow: string;
  title: [string, string];
  body: string;
  image: { src: string; width: number; height: number; alt: string };
  /** Chapter action: preselect a session type, or go to the invitation form. */
  action: { label: string; sessionType: SessionType } | { label: string; href: "#invitation" };
  note?: string;
}

// Copy from docs/content.md — proposed, pending client approval.
export const programmes: Programme[] = [
  {
    id: "yoga",
    number: "01",
    verb: "Move",
    name: "Yoga",
    indexLabel: "Yoga",
    strapline: ["Wake", "the body."],
    icon: "leaf",
    eyebrow: "Move / Yoga",
    title: ["Movement,", "without the rush."],
    body: "An invitation to explore movement with attention. A thoughtful pace, space to pause, and a session shaped around the experience you discuss with the team.",
    image: { ...media.yoga, alt: "Concept illustration of an outdoor yoga session" },
    action: { label: "Request a yoga session", sessionType: "Yoga" },
  },
  {
    id: "meditation",
    number: "02",
    verb: "Be still",
    name: "Meditation",
    indexLabel: "Meditation",
    strapline: ["Make space", "for silence."],
    icon: "lotus",
    eyebrow: "Be still / Meditation",
    title: ["Make room", "for stillness."],
    body: "Step away from the need to do more. Discover a quiet moment of attention, with space to settle and simply be present.",
    image: { ...media.meditation, alt: "Concept portrait showing a quiet moment of meditation" },
    action: { label: "Request a meditation session", sessionType: "Meditation" },
  },
  {
    id: "sound",
    number: "03",
    verb: "Listen",
    name: "Music & Sound",
    indexLabel: "Music & Sound",
    strapline: ["Change", "the rhythm."],
    icon: "waves",
    eyebrow: "Listen / Music & Sound",
    title: ["Let the moment", "unfold in sound."],
    body: "A quieter kind of listening. Explore music and sound as part of a considered wellness experience, with room for silence between the notes.",
    image: { ...media.sound, alt: "Illustrative sound bowl in a calm sunlit setting" },
    action: { label: "Explore a sound session", sessionType: "Music & Sound" },
    note: "No audio plays automatically. Silence is part of the experience.",
  },
  {
    id: "connection",
    number: "04",
    verb: "Connect",
    name: "Private Group Sessions",
    indexLabel: "Private groups",
    strapline: ["The conversations", "you remember."],
    icon: "people",
    eyebrow: "Connect / Private groups",
    title: ["A shared moment.", "A smaller circle."],
    body: "Some experiences become meaningful through the people we share them with. Private group sessions make room for presence, conversation and connection within an invitation-led setting.",
    image: { ...media.community, alt: "Illustrative small-group wellness circle; not actual members" },
    action: { label: "Request an invitation", href: "#invitation" },
  },
];

export function programme(id: Programme["id"]): Programme {
  const found = programmes.find((p) => p.id === id);
  if (!found) throw new Error(`Unknown programme: ${id}`);
  return found;
}
