/**
 * Site-wide settings and media. Values marked "pending" are client decisions
 * listed in docs/client-inputs.md — do not replace them with invented details.
 */

export const site = {
  name: "NOURA",
  tagline: "Illuminate your wellbeing",
  description:
    "A private space for yoga, meditation, sound and meaningful connection. Thoughtful experiences, shared at an unhurried pace.",
  /** Pending (client-inputs #17): approved public email/phone. Hidden while null. */
  publicContact: null as { email?: string; phone?: string } | null,
  /** Pending (client-inputs #17): approved social profiles. Hidden while empty. */
  social: [] as { label: string; href: string }[],
  /**
   * Forms stay in preview mode until the backend slice (docs/implementation-plan.md #29–33)
   * stores requests. In preview mode nothing is sent and the UI says so.
   */
  requestsMode: "preview" as "preview" | "live",
} as const;

export const nav = [
  { label: "Our philosophy", href: "#philosophy" },
  { label: "The experiences", href: "#experiences" },
  { label: "Your invitation", href: "#journey" },
] as const;

/** The full-story menu behind the header's menu button: anchors to existing sections only. */
export const menu = [
  { label: "A pause", href: "#pause" },
  { label: "Our philosophy", href: "#philosophy" },
  { label: "The experiences", href: "#experiences" },
  { label: "Session rhythm", href: "#rhythm" },
  { label: "Your invitation", href: "#journey" },
  { label: "Member card", href: "#member" },
  { label: "Care & privacy", href: "#care" },
  { label: "Questions", href: "#questions" },
  { label: "Private session", href: "#private-session" },
] as const;

export const media = {
  wordmark: { src: "/media/noura-wordmark.webp", width: 640, height: 166 },
  /**
   * The same supplied wordmark with only its off-white ground made transparent (mark pixels
   * unchanged), so it can sit over the hero. Presentation derivative; replace with the
   * original vector export once supplied (docs/design.md → logo, client-inputs).
   */
  wordmarkTransparent: { src: "/media/noura-wordmark-transparent.webp", width: 640, height: 166 },
  logo: { src: "/media/noura-logo.webp", width: 681, height: 754 },
  hero: {
    /**
     * Static hero still (no background film). Illustrative, AI-generated scene — not NOURA's
     * premises (docs/asset-manifest.md). `posterMobile` is the portrait recomposition used on
     * portrait screens. Replace the file names here to swap the image.
     */
    poster: { src: "/media/hero-poster-bright-v2.jpg", width: 1920, height: 1080 },
    posterMobile: { src: "/media/hero-poster-mobile-bright-v2.jpg", width: 1080, height: 1920 },
  },
  botanical: { src: "/media/botanical.webp", width: 354, height: 303 },
  yoga: { src: "/media/yoga.webp", width: 699, height: 384 },
  meditation: { src: "/media/meditation.webp", width: 603, height: 366 },
  sound: { src: "/media/sound.webp", width: 672, height: 321 },
  community: { src: "/media/community.webp", width: 603, height: 360 },
} as const;
