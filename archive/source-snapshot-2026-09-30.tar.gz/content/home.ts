// Landing copy from docs/content.md. Proposed wording for Sidhart's review, not approved
// business claims: no founder story, venue, capacity, response time or outcome is asserted.

export const hero = {
  titleLines: ["A quieter moment.", "A deeper connection."],
  /** Second sentence of the approved hero intro, set as the italic line. */
  subtitle: "Thoughtful experiences, shared at an unhurried pace.",
  /** First sentence of the intro, condensed into the small meta line. No venue or dates are asserted. */
  meta: ["By invitation", "Yoga / Meditation / Sound / Connection"],
  primary: "Request an invitation",
  /** Visible label of the scroll cue. */
  scrollLabel: "Scroll",
  /** Secondary action beside the invitation CTA; links to the experience index. */
  secondary: "Explore the experience",
};

/** 01b — Overview strip under the arrival: the four experiences at a glance. */
export const ways = {
  eyebrow: "The journey",
  titleLines: ["Reset. Reconnect.", "Reimagine."],
  link: "Explore the journey",
  /** Stands in for the reference's "Our story" slot: no founder history is asserted. */
  aside: {
    eyebrow: "The intention",
    lines: ["A little less noise.", "A little more presence."],
    link: "Read the intention",
  },
};

export const pause = {
  title: "You do not have to fill every moment.",
  body: "Some moments are simply yours to notice. A change in the light. A gentler rhythm. A little space to be here.",
};

export const philosophy = {
  eyebrow: "The NOURA intention",
  titleLines: ["A little less noise.", "A little more presence."],
  // Pending: replace "is imagined as" once the client confirms the positioning.
  lead: "NOURA is imagined as a considered space for movement, stillness, sound and connection. Not another thing to rush through. An invitation to meet the moment with attention.",
  quiet: "A mindful experience begins with how it makes room for you.",
  imageAlt: "Illustrative botanical scene in warm natural light",
  imageNote: "Proposed brand narrative and concept imagery for review.",
};

export const experiences = {
  eyebrow: "The experiences",
  titleLines: ["Four ways to come back", "to the moment."],
  intro: "Each experience has its own rhythm. Each begins with attention.",
};

export const connectionFooter = "Private experiences / thoughtful connection";

export const rhythm = {
  eyebrow: "A possible session rhythm",
  titleLines: ["Unhurried, from", "beginning to end."],
  steps: [
    { title: "Arrive", body: "Leave space to settle." },
    { title: "Settle", body: "Meet the moment with attention." },
    { title: "Explore", body: "Take part in the agreed experience." },
    { title: "Close", body: "Bring the session to a thoughtful end." },
  ],
  note: "Illustrative sequence for client approval. Actual sessions and inclusions are confirmed by the team.",
};

export const space = {
  title: "Room to slow down.",
  lines: ["Light. Texture. Quiet.", "The setting should support the experience, not compete with it."],
};

export const journey = {
  eyebrow: "Your invitation",
  titleLines: ["A thoughtful welcome,", "not an instant booking."],
  steps: [
    {
      title: "Share your interest",
      body: "Tell the team what brings you here through an invitation or private-session request.",
    },
    { title: "A personal review", body: "Your details are reviewed privately by the authorized team." },
    {
      title: "Receive next steps",
      body: "Approved requests are followed up with the next step in the conversation.",
    },
  ],
  notice:
    "A request does not automatically approve membership or reserve a session. A preferred date remains a preference until the team confirms it.",
};

export const member = {
  eyebrow: "A considered detail",
  titleLines: ["A personal detail.", "A sense of belonging."],
  lead: "Approved members can receive a personalized digital card with their unique member number. A small, considered part of the experience.",
  quiet: "A card represents your member record. It is not a public profile or a payment card.",
  // Demonstration only (docs/data-model.md → ID format). Never a real member.
  card: { label: "By invitation", name: "Sample member", code: "NRA-DEMO-001", note: "Demonstration card / no live member data" },
};

export const care = {
  eyebrow: "Care, in the details",
  titleLines: ["Privacy is part", "of the welcome."],
  items: [
    {
      icon: "lock",
      title: "Private review",
      body: "Requests are intended for authorized team members, not a public directory.",
    },
    {
      icon: "people",
      title: "Human follow-up",
      body: "The next step is a considered conversation, not automatic acceptance.",
    },
    {
      icon: "shield",
      title: "Only what is needed",
      body: "Ask for relevant details and explain how the request will be handled.",
    },
  ],
} as const;

export const invitationSection = {
  eyebrow: "Request an invitation",
  titleLines: ["Your next chapter", "starts with a conversation."],
  intro:
    "Share a little about yourself and the experience that interests you. Every request is reviewed before next steps are shared.",
  quiet: "No payment is required through this form. Submitting it does not approve membership.",
};

export const sessionSection = {
  eyebrow: "Request a private session",
  titleLines: ["Prefer a", "private session?"],
  intro:
    "Choose the experience you would like to explore and share a preferred date. The team will review your request and discuss the details with you.",
  quiet: "This is a request, not an instant booking. A preferred date is not reserved until confirmed.",
};

export const requestCopy = {
  /** Production confirmation (docs/requirements.md → submission outcomes). */
  received:
    "Your request has been received. Our team will review it and contact you with next steps. This is not a confirmed booking or membership approval.",
  preview:
    "Preview only: your request would be received for manual review. No information has been sent or saved. This is not a confirmed booking or membership approval.",
  previewNote: "Design preview. No information is sent, stored or used to approve a request.",
};

export const footer = {
  closing: ["Come as you are.", "Take your time."],
  note: "Proposed copy and illustrative artwork · public contact, legal text and final footage pending approval.",
};

export const notice = {
  title: "Privacy & terms",
  paragraphs: [
    "This website is in review. Forms do not yet send or save information, create memberships or reserve sessions. Please use fictional details only.",
    "Client-approved privacy and terms information will be published here before any real request is collected. The imagery is illustrative, not proof of an actual venue, member or practitioner.",
  ],
};
