export const faqSection = {
  eyebrow: "Before you begin",
  titleLines: ["A few things,", "gently clarified."],
};

// docs/content.md → FAQs. No response time is promised until confirmed by the client.
export const faqs = [
  {
    q: "Is this an instant booking website?",
    a: "No. Session and invitation requests are reviewed by the team. A preferred date is not a confirmed booking.",
  },
  {
    q: "How do I request an invitation?",
    a: "Complete the invitation form with your details and interests. The team will review your request and share next steps where appropriate.",
  },
  {
    q: "Can I request a private session instead?",
    a: "Yes. Use the separate private-session form and choose the experience that interests you.",
  },
  {
    q: "Do I pay on the website?",
    a: "There is no online payment step in this request flow.",
  },
  {
    q: "When will I hear back?",
    a: "The team will contact you after reviewing the request. A specific response time will only be published after it has been confirmed by the team.",
  },
];
