# NOURA — The Quiet Invitation

A calm, long-form landing page for NOURA, a private wellness community: yoga, meditation, Music & Sound and private group sessions, with a silent background film in the hero and two manually reviewed request flows.

Built with Next.js 16 (App Router) and TypeScript. The approved specification lives in [`docs/`](docs/README.md); read [`AGENTS.md`](AGENTS.md) before changing anything.

## Getting started

```bash
npm install
cp .env.example .env.local   # optional; defaults are safe for local work
npm run dev                  # http://localhost:3000
```

| Script | What it does |
|---|---|
| `npm run dev` | Development server |
| `npm run build` / `npm start` | Production build / serve |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run lint` | ESLint (Next.js core-web-vitals + TypeScript rules) |
| `npm test` | Unit tests (Node's built-in runner) for the request validation rules |
| `npm run check` | All three checks above |

Requires Node.js ≥ 20.9 (tests use Node's type stripping, available in Node 22.6+).

## Repository layout

```
app/
  layout.tsx              fonts (next/font, self-hosted at build), metadata, skip link
  globals.css             base styles, typography, buttons, photos, ornament, reveal
  (public)/page.tsx       the single long landing page, in the approved narrative order
components/
  layout/                 SiteHeader, SiteFooter, NoticeDialog, RevealObserver
  story/                  Hero + HeroFilm, interludes, philosophy, experience index & chapters,
                          rhythm/journey/care, member card, FAQ
  forms/                  InvitationForm, SessionForm, accessible field primitives
  ui/                     Icon, Button/TextLink, Photo, Ornament, SectionHeading
content/                  all public copy and media references (typed, reviewable)
lib/
  validation/requests.ts  field rules shared by browser and future server routes
  requests/client.ts      submission client (preview mode until the backend slice)
  events.ts               cross-component events (programme preselect, notice dialog)
styles/tokens.css         design tokens — the single source for colour, type, space, motion
public/media/             logo, poster, stills and hero film (decoded from the reference HTML)
tests/unit/               validation tests
docs/                     specification set, icon sources, and the reference presentation HTML
```

## The hero film

`components/story/HeroFilm.tsx` follows the playback model in `docs/media-motion.md`:

- The poster renders first (prioritised image); headline and CTAs are real HTML and never wait for video.
- No video source is assigned under `prefers-reduced-motion` or a data-saver preference.
- Otherwise it plays muted, looped and inline, choosing a 960px mobile derivative on narrow screens, and crossfades in once frames arrive.
- Blocked autoplay or a media error leaves the poster and shows a usable **Play film** control.
- A persistent ≥44px pause/play control; an explicit pause survives scrolling away and back and tab switches. Playback pauses off-screen and in hidden tabs.

To replace the footage, drop new files into `public/media/` (new filenames — media is served with immutable caching), update `media.hero` in `content/site.ts`, and set `isPlaceholder: false` once the footage is approved.

## Status of this slice

**Done (public landing page):** all 18 blocks from `docs/site-structure.md`; hero film; anchor navigation and mobile menu; chapter CTAs that preselect the session form; accessible FAQ; both forms with full client validation, error summary, retry and outcome states; privacy/terms notice dialog; security headers; noindex until launch.

**Forms are in preview mode.** `site.requestsMode` is `"preview"`: nothing leaves the browser and the UI says so. The live branch in `lib/requests/client.ts` already speaks the contract in `docs/architecture.md`, but the endpoints don't exist yet.

**Next slices** (`docs/implementation-plan.md` #29–36): Supabase schema, migrations and RLS; `POST /api/requests/{invitation,session}` re-using `lib/validation`; admin auth and review queues; member approval; card export.

**Client inputs still pending** (`docs/client-inputs.md`) — the site uses placeholders or hides the slot until these arrive:

- Final hero footage (the current loop is a motion study made from concept artwork and is labelled as such).
- The original vector / transparent logo. The supplied raster has a soft cream glow baked around the wordmark, visible on white.
- Approved programme photography.
- Public contact and social links (hidden while empty in `content/site.ts`).
- Approved privacy and terms wording.
- Brand positioning copy (the "is imagined as" wording in `content/home.ts`).
- Operating timezone for date validation.
- Favicon from the brand source.
